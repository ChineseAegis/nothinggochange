#pragma once

class MobileEquipment
{
public:
   int x,y;//坐标

   MobileEquipment(){

   }
   MobileEquipment(int x,int y):x(x),y(y)
   {
    
   }

};
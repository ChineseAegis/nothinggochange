// //这是自己本地的测试文件，仅在此对自己的代码做测试，不要提交该文件到仓库
// //test.cpp和main.cpp不能同时运行，注释掉其中一个后再编译运行
// #pragma once
// #define CATCH_CONFIG_MAIN
// #include "catch.hpp"
// #include"Map.hpp"
// #include"PortManager.hpp"
// #include<iostream>
// void test01();
// TEST_CASE("catch_test","[test]"){
//     test01();
//     PortManager p;

// }
// void test01(){
//   REQUIRE(1==true);
//     Map map;
//     map.readfile("/home/ubuntu/project/Huawei-LH/Huawei-LH/src/map1.txt");
//     for(const auto& row : map.grid){
//       for(Element cell:row){
//         std::cout<<cell.type<<" ";
//       }
//       std::cout<<std::endl;
//     }
// }